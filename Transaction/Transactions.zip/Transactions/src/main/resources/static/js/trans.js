function getAccount(url, parms, callback) {
	document.getElementById("withdraw").value = "";
	document.getElementById("deposit").value = "";
	document.getElementById("alert").style.display = "none";
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			respo = JSON.parse(this.responseText);
			if (respo.error != "") {
				document.getElementById("errormes").innerHTML = respo.error;
				document.getElementById("alert").style.display = "block";
			}
			document.getElementById("accountNumber").innerHTML = respo.accountNumber;
			document.getElementById("accountBal").innerHTML = "$"
					+ respo.balanceAmount;
		} else {
			// alert("Fail");
		}
	};
	xhttp.open("POST", url, true);
	xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	xhttp.send(parms);
}
getAccount("transaction/getaccount", "", "");

function deposit() {
	getAccount("transaction/getaccount", "", "");
}

function withdraw() {
	amount = document.getElementById("withdraw").value;
	if (amount != null && amount > 0)
		getAccount("transaction/withdraw", "amount=" + amount, "");
	else
		alert("please enter valid amout")
}
function deposit() {
	amount = document.getElementById("deposit").value;
	if (amount != null && amount > 0)
		getAccount("transaction/deposit", "amount=" + amount, "");
	else
		alert("please enter valid amout")
}
function logout() {
	window.location.href = "logout";
}