package org.ras.bank.trans.bean;

public final class AccountDetails {

	public AccountDetails(String userName, String accountNumber, double balanceAmount, int accountIntelID,
			boolean isAccountAcive) {
		this.userName = userName;
		this.accountIntelID = accountIntelID;
		this.accountNumber = accountNumber;
		this.balanceAmount = balanceAmount;
		this.isAccountAcive = isAccountAcive;
	}

	String userName;
	String accountNumber;
	double balanceAmount;
	boolean isAccountAcive;
	Integer accountIntelID;
	String error="";
	int maxDeposit=40000;

	public Integer getAccountIntelID() {
		return accountIntelID;
	}
	public int getMaxDeposit() {
		return maxDeposit;
	}

	public String getError() {
		return error;
	}
	public String getUserName() {
		return userName;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public double getBalanceAmount() {
		return balanceAmount;
	}

	public boolean isAccountAcive() {
		return isAccountAcive;
	}

	public void setBalanceAmount(double balanceAmount) {
		this.balanceAmount = balanceAmount;
	}

	public void setError(String error) {
		this.error = error;
	}

	@Override
	public int hashCode() {
		return this.accountIntelID;
	}

	@Override
	public boolean equals(Object obj) {
		AccountDetails account = (AccountDetails) obj;
		return this.accountIntelID == account.accountIntelID;
	}

}
