package org.ras.bank.trans.cont;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/")
public class LoginControler {
	
	
	@RequestMapping("/loginprocess")
	public String login(@RequestParam("username") String username,@RequestParam("password") String password)
	{		
		System.out.println("Login Controler :: " + username );
		return "sucess";
	}
	

}
