package org.ras.bank.trans.cont;

import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;

import org.ras.bank.trans.bean.AccountDetails;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/transaction")
public class TransactionControler {
	private Map<String, AccountDetails> accountHolder = new HashMap<>();

	@RequestMapping("/withdraw")
	public AccountDetails withdraw(@RequestParam("amount") double amount,
			HttpServletRequest request) {

		AccountDetails accountDetails = this.getAccount(request.getUserPrincipal().getName(), request);
		double curtbal = accountDetails.getBalanceAmount();
		if (amount > curtbal)
			accountDetails.setError("Please enter amount below then [ " + curtbal + " ] ");
		else
			accountDetails.setBalanceAmount(getAmount(curtbal - amount));

		return accountDetails;

	}
	@RequestMapping("/deposit")
	public AccountDetails deposit(@RequestParam("amount") double amount,
			HttpServletRequest request) {

		AccountDetails accountDetails = this.getAccount(request.getUserPrincipal().getName(), request);
		double maxde = accountDetails.getMaxDeposit();
		if (amount > maxde)
			accountDetails.setError("Please enter amount below then [ " + maxde + " ] ");
		else
			accountDetails.setBalanceAmount(getAmount(accountDetails.getBalanceAmount() + amount));

		return accountDetails;

	}
	// @RequestParam("account") Integer account,

	@RequestMapping("/getaccount")
	public AccountDetails getAccountDetaails(HttpServletRequest request) {

		return this.getAccount(request.getUserPrincipal().getName(), request);
	}

	private AccountDetails getAccount(String name, HttpServletRequest request) {
		AccountDetails accountDetails = this.accountHolder.get(name);
		if (accountDetails == null) {
			accountDetails = buildAccount(request);
		}
		accountDetails.setError("");
		return accountDetails;
	}

	private AccountDetails buildAccount(HttpServletRequest request) {
		Random random = new Random();
		Integer account = random.nextInt(Integer.MAX_VALUE - 345623) + 345623;

		double amount = getAmount(random.nextDouble() * 1 + (random.nextInt(20000) - 1));
		String userName = request.getUserPrincipal().getName();
		AccountDetails accountDetails = new AccountDetails(userName, "ACC" + account, amount, account, true);
		this.accountHolder.put(userName, accountDetails);
		return accountDetails;

	}

	private double getAmount(double amount) {

		DecimalFormat df = new DecimalFormat("#.##");
		return Double.valueOf(df.format(amount));
	}

}
